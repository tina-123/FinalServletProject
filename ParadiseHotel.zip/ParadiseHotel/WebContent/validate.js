function validate()
{
	var password = frm1.password.value;
	var confirmpassword = frm1.confirmpassword.value;
	
	if( password == confirmpassword )
		{
			frm1.action="addUser.hb";
		}
	else
		{
		 alert("password did not matched");
		}
}